﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Assignment_Arbin
{
    public partial class CandidateInfo : Form
    {
        private List<Contact> contactList;
        private string connectionString = "Data Source=DESKTOP-K768ED7;Initial Catalog=arbin;Integrated Security=True";
        private SqlConnection connection;
        public CandidateInfo()
        {
            InitializeComponent();
            contactList = new List<Contact>();
            connection = new SqlConnection(connectionString);
        }

        public class Contact
        {
            public int ContactNumber { get; set; }
            public string Name { get; set; }
            public string Gender { get; set; }
            public bool FamiliarWithC { get; set; }
            public bool FamiliarWithCSharp { get; set; }
            public bool FamiliarWithVB { get; set; }
            public bool FamiliarWithDelphi { get; set; }
            public string Hobbies { get; set; }

            public Contact(int contactNumber, string name, string gender, bool familiarWithC, bool familiarWithCSharp, bool familiarWithVB, bool familiarWithDelphi, string hobbies)
            {
                ContactNumber = contactNumber;
                Name = name;
                Gender = gender;
                FamiliarWithC = familiarWithC;
                FamiliarWithCSharp = familiarWithCSharp;
                FamiliarWithVB = familiarWithVB;
                FamiliarWithDelphi = familiarWithDelphi;
                Hobbies = hobbies;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveContactData();
            LoadContactData();
            ClearForm();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateContactData();
            LoadContactData();
            ClearForm();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteContactData();
            LoadContactData();
            ClearForm();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearchKeyword.Text;
            SearchContactData(keyword);
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if a contact is selected from the list
            int selectedIndex = lstContacts.SelectedIndex;
            if (selectedIndex >= 0)
            {
                // Retrieve the contact from the list
                Contact contact = contactList[selectedIndex];

                // Populate the form controls with the contact information
                txtContactNumber.Text = contact.ContactNumber.ToString();
                txtName.Text = contact.Name;
                cmbGender.SelectedItem = contact.Gender;
                chkC.Checked = contact.FamiliarWithC;
                chkCSharp.Checked = contact.FamiliarWithCSharp;
                chkVB.Checked = contact.FamiliarWithVB;
                chkDelphi.Checked = contact.FamiliarWithDelphi;
                txtHobbies.Text = contact.Hobbies;
            }
        }

        private void ClearForm()
        {
            txtContactNumber.Text = string.Empty;
            txtName.Text = string.Empty;
            cmbGender.SelectedIndex = -1;
            chkC.Checked = false;
            chkCSharp.Checked = false;
            chkVB.Checked = false;
            chkDelphi.Checked = false;
            txtHobbies.Text = string.Empty;
        }

        private void LoadContactData()
        {
            contactList.Clear();

            try
            {
                connection.Open();

                string selectDataQuery = "SELECT * FROM CandidateInfo";
                SqlCommand selectDataCommand = new SqlCommand(selectDataQuery, connection);
                SqlDataReader reader = selectDataCommand.ExecuteReader();

                while (reader.Read())
                {
                    int contactNumber = Convert.ToInt32(reader["ContactNumber"]);
                    string name = reader["Name"].ToString();
                    string gender = reader["Gender"].ToString();
                    bool familiarWithC = Convert.ToBoolean(reader["FamiliarWithC"]);
                    bool familiarWithCSharp = Convert.ToBoolean(reader["FamiliarWithCSharp"]);
                    bool familiarWithVB = Convert.ToBoolean(reader["FamiliarWithVB"]);
                    bool familiarWithDelphi = Convert.ToBoolean(reader["FamiliarWithDelphi"]);
                    string hobbies = reader["Hobbies"].ToString();

                    Contact contact = new Contact(contactNumber, name, gender, familiarWithC, familiarWithCSharp, familiarWithVB, familiarWithDelphi, hobbies);
                    contactList.Add(contact);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while loading contact data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }

            RefreshContactList();
        }

        private void SaveContactData()
        {
            try
            {
                connection.Open();

                foreach (Contact contact in contactList)
                {
                    string insertDataQuery = "INSERT INTO CandidateInfo (ContactNumber, Name, Gender, FamiliarWithC, FamiliarWithCSharp, FamiliarWithVB, FamiliarWithDelphi, Hobbies) VALUES (@ContactNumber, @Name, @Gender, @FamiliarWithC, @FamiliarWithCSharp, @FamiliarWithVB, @FamiliarWithDelphi, @Hobbies)";
                    SqlCommand insertDataCommand = new SqlCommand(insertDataQuery, connection);
                    insertDataCommand.Parameters.AddWithValue("@ContactNumber", contact.ContactNumber);
                    insertDataCommand.Parameters.AddWithValue("@Name", contact.Name);
                    insertDataCommand.Parameters.AddWithValue("@Gender", contact.Gender);
                    insertDataCommand.Parameters.AddWithValue("@FamiliarWithC", contact.FamiliarWithC);
                    insertDataCommand.Parameters.AddWithValue("@FamiliarWithCSharp", contact.FamiliarWithCSharp);
                    insertDataCommand.Parameters.AddWithValue("@FamiliarWithVB", contact.FamiliarWithVB);
                    insertDataCommand.Parameters.AddWithValue("@FamiliarWithDelphi", contact.FamiliarWithDelphi);
                    insertDataCommand.Parameters.AddWithValue("@Hobbies", contact.Hobbies);
                    insertDataCommand.ExecuteNonQuery();
                }

                MessageBox.Show("Contact data saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while saving contact data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void UpdateContactData()
        {
            int selectedIndex = lstContacts.SelectedIndex;
            if (selectedIndex >= 0)
            {
                Contact selectedContact = contactList[selectedIndex];

                try
                {
                    connection.Open();

                    string updateDataQuery = "UPDATE CandidateInfo SET Name = @Name, Gender = @Gender, FamiliarWithC = @FamiliarWithC, FamiliarWithCSharp = @FamiliarWithCSharp, FamiliarWithVB = @FamiliarWithVB, FamiliarWithDelphi = @FamiliarWithDelphi, Hobbies = @Hobbies WHERE ContactNumber = @ContactNumber";
                    SqlCommand updateDataCommand = new SqlCommand(updateDataQuery, connection);
                    updateDataCommand.Parameters.AddWithValue("@Name", txtName.Text);
                    updateDataCommand.Parameters.AddWithValue("@Gender", cmbGender.SelectedItem.ToString());
                    updateDataCommand.Parameters.AddWithValue("@FamiliarWithC", chkC.Checked);
                    updateDataCommand.Parameters.AddWithValue("@FamiliarWithCSharp", chkCSharp.Checked);
                    updateDataCommand.Parameters.AddWithValue("@FamiliarWithVB", chkVB.Checked);
                    updateDataCommand.Parameters.AddWithValue("@FamiliarWithDelphi", chkDelphi.Checked);
                    updateDataCommand.Parameters.AddWithValue("@Hobbies", txtHobbies.Text);
                    updateDataCommand.Parameters.AddWithValue("@ContactNumber", selectedContact.ContactNumber);
                    updateDataCommand.ExecuteNonQuery();

                    MessageBox.Show("Contact data updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while updating contact data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
            else
            {
                MessageBox.Show("Please select a contact to update.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeleteContactData()
        {
            int selectedIndex = lstContacts.SelectedIndex;
            if (selectedIndex >= 0)
            {
                Contact selectedContact = contactList[selectedIndex];

                try
                {
                    connection.Open();

                    string deleteDataQuery = "DELETE FROM CandidateInfo WHERE ContactNumber = @ContactNumber";
                    SqlCommand deleteDataCommand = new SqlCommand(deleteDataQuery, connection);
                    deleteDataCommand.Parameters.AddWithValue("@ContactNumber", selectedContact.ContactNumber);
                    deleteDataCommand.ExecuteNonQuery();

                    MessageBox.Show("Contact data deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while deleting contact data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
            else
            {
                MessageBox.Show("Please select a contact to delete.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void SearchContactData(string keyword)
        {
            try
            {
                connection.Open();

                string searchQuery = "SELECT * FROM CandidateInfo WHERE Name LIKE @Keyword";
                SqlCommand searchCommand = new SqlCommand(searchQuery, connection);
                searchCommand.Parameters.AddWithValue("@Keyword", "%" + keyword + "%");
                SqlDataReader reader = searchCommand.ExecuteReader();

                contactList.Clear();

                while (reader.Read())
                {
                    int contactNumber = Convert.ToInt32(reader["ContactNumber"]);
                    string name = reader["Name"].ToString();
                    string gender = reader["Gender"].ToString();
                    bool familiarWithC = Convert.ToBoolean(reader["FamiliarWithC"]);
                    bool familiarWithCSharp = Convert.ToBoolean(reader["FamiliarWithCSharp"]);
                    bool familiarWithVB = Convert.ToBoolean(reader["FamiliarWithVB"]);
                    bool familiarWithDelphi = Convert.ToBoolean(reader["FamiliarWithDelphi"]);
                    string hobbies = reader["Hobbies"].ToString();

                    Contact contact = new Contact(contactNumber, name, gender, familiarWithC, familiarWithCSharp, familiarWithVB, familiarWithDelphi, hobbies);
                    contactList.Add(contact);
                }

                RefreshContactList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching contact data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void RefreshContactList()
        {
            lstContacts.Items.Clear();

            foreach (Contact contact in contactList)
            {
                lstContacts.Items.Add(contact.Name);
            }
        }


        private void lstContacts_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if a contact is selected from the list
            int selectedIndex = lstContacts.SelectedIndex;
            if (selectedIndex >= 0)
            {
                // Retrieve the contact from the list
                Contact contact = contactList[selectedIndex];

                // Populate the form controls with the contact information
                txtContactNumber.Text = contact.ContactNumber.ToString();
                txtName.Text = contact.Name;
                cmbGender.SelectedItem = contact.Gender;
                chkC.Checked = contact.FamiliarWithC;
                chkCSharp.Checked = contact.FamiliarWithCSharp;
                chkVB.Checked = contact.FamiliarWithVB;
                chkDelphi.Checked = contact.FamiliarWithDelphi;
                txtHobbies.Text = contact.Hobbies;
            }
        }

        private void CandidateInfo_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'arbinDataSet1.CandidateInfo' table. You can move, or remove it, as needed.
            this.candidateInfoTableAdapter1.Fill(this.arbinDataSet1.CandidateInfo);
            // TODO: This line of code loads data into the 'arbinDataSet.CandidateInfo' table. You can move, or remove it, as needed.
            //this.candidateInfoTableAdapter.Fill(this.arbinDataSet.CandidateInfo);

        }
    }

    
}
    

