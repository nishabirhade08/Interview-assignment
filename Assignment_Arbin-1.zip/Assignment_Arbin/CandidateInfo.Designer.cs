﻿namespace Assignment_Arbin
{
    partial class CandidateInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.candidateInfoBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.arbinDataSet1 = new Assignment_Arbin.arbinDataSet1();
            this.txtContactNumber = new System.Windows.Forms.TextBox();
            this.txtHobbies = new System.Windows.Forms.TextBox();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.chkC = new System.Windows.Forms.CheckBox();
            this.chkCSharp = new System.Windows.Forms.CheckBox();
            this.chkVB = new System.Windows.Forms.CheckBox();
            this.chkDelphi = new System.Windows.Forms.CheckBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearchKeyword = new System.Windows.Forms.TextBox();
            this.lstContacts = new System.Windows.Forms.ListBox();
            this.candidateInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.candidateInfoTableAdapter1 = new Assignment_Arbin.arbinDataSet1TableAdapters.CandidateInfoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.candidateInfoBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arbinDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.candidateInfoBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Name          :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 59);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Contact No. :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 90);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Gender       :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(27, 118);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(228, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Familiar Programming Languages :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(27, 250);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Hobbies      :";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(152, 28);
            this.txtName.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(425, 20);
            this.txtName.TabIndex = 10;
            // 
            // candidateInfoBindingSource1
            // 
            this.candidateInfoBindingSource1.DataMember = "CandidateInfo";
            this.candidateInfoBindingSource1.DataSource = this.arbinDataSet1;
            // 
            // arbinDataSet1
            // 
            this.arbinDataSet1.DataSetName = "arbinDataSet1";
            this.arbinDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtContactNumber
            // 
            this.txtContactNumber.Location = new System.Drawing.Point(152, 58);
            this.txtContactNumber.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtContactNumber.Name = "txtContactNumber";
            this.txtContactNumber.Size = new System.Drawing.Size(229, 20);
            this.txtContactNumber.TabIndex = 11;
            // 
            // txtHobbies
            // 
            this.txtHobbies.Location = new System.Drawing.Point(152, 247);
            this.txtHobbies.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtHobbies.Name = "txtHobbies";
            this.txtHobbies.Size = new System.Drawing.Size(425, 20);
            this.txtHobbies.TabIndex = 12;
            // 
            // cmbGender
            // 
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.cmbGender.Location = new System.Drawing.Point(152, 90);
            this.cmbGender.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(140, 21);
            this.cmbGender.TabIndex = 13;
            // 
            // chkC
            // 
            this.chkC.AutoSize = true;
            this.chkC.Location = new System.Drawing.Point(152, 142);
            this.chkC.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkC.Name = "chkC";
            this.chkC.Size = new System.Drawing.Size(62, 17);
            this.chkC.TabIndex = 14;
            this.chkC.Text = "C/C++";
            this.chkC.UseVisualStyleBackColor = true;
            // 
            // chkCSharp
            // 
            this.chkCSharp.AutoSize = true;
            this.chkCSharp.Location = new System.Drawing.Point(152, 165);
            this.chkCSharp.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkCSharp.Name = "chkCSharp";
            this.chkCSharp.Size = new System.Drawing.Size(42, 17);
            this.chkCSharp.TabIndex = 15;
            this.chkCSharp.Text = "C#";
            this.chkCSharp.UseVisualStyleBackColor = true;
            // 
            // chkVB
            // 
            this.chkVB.AutoSize = true;
            this.chkVB.Location = new System.Drawing.Point(152, 188);
            this.chkVB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkVB.Name = "chkVB";
            this.chkVB.Size = new System.Drawing.Size(42, 17);
            this.chkVB.TabIndex = 16;
            this.chkVB.Text = "VB";
            this.chkVB.UseVisualStyleBackColor = true;
            // 
            // chkDelphi
            // 
            this.chkDelphi.AutoSize = true;
            this.chkDelphi.Location = new System.Drawing.Point(152, 211);
            this.chkDelphi.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkDelphi.Name = "chkDelphi";
            this.chkDelphi.Size = new System.Drawing.Size(62, 17);
            this.chkDelphi.TabIndex = 17;
            this.chkDelphi.Text = "Delphi";
            this.chkDelphi.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(158, 311);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(88, 26);
            this.btnSave.TabIndex = 18;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(285, 311);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(88, 26);
            this.btnUpdate.TabIndex = 19;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(406, 311);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(88, 26);
            this.btnDelete.TabIndex = 20;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(1087, 311);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(88, 26);
            this.btnSearch.TabIndex = 21;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearchKeyword
            // 
            this.txtSearchKeyword.Location = new System.Drawing.Point(621, 314);
            this.txtSearchKeyword.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSearchKeyword.Name = "txtSearchKeyword";
            this.txtSearchKeyword.Size = new System.Drawing.Size(434, 20);
            this.txtSearchKeyword.TabIndex = 23;
            // 
            // lstContacts
            // 
            this.lstContacts.FormattingEnabled = true;
            this.lstContacts.Location = new System.Drawing.Point(621, 28);
            this.lstContacts.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lstContacts.Name = "lstContacts";
            this.lstContacts.Size = new System.Drawing.Size(554, 251);
            this.lstContacts.TabIndex = 24;
            this.lstContacts.SelectedIndexChanged += new System.EventHandler(this.lstContacts_SelectedIndexChanged);
            // 
            // candidateInfoTableAdapter1
            // 
            this.candidateInfoTableAdapter1.ClearBeforeFill = true;
            // 
            // CandidateInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1194, 450);
            this.Controls.Add(this.lstContacts);
            this.Controls.Add(this.txtSearchKeyword);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.chkDelphi);
            this.Controls.Add(this.chkVB);
            this.Controls.Add(this.chkCSharp);
            this.Controls.Add(this.chkC);
            this.Controls.Add(this.cmbGender);
            this.Controls.Add(this.txtHobbies);
            this.Controls.Add(this.txtContactNumber);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "CandidateInfo";
            this.Text = "CandidateInfo";
            this.Load += new System.EventHandler(this.CandidateInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.candidateInfoBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arbinDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.candidateInfoBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtContactNumber;
        private System.Windows.Forms.TextBox txtHobbies;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.CheckBox chkC;
        private System.Windows.Forms.CheckBox chkCSharp;
        private System.Windows.Forms.CheckBox chkVB;
        private System.Windows.Forms.CheckBox chkDelphi;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearchKeyword;
        private System.Windows.Forms.ListBox lstContacts;
        private arbinDataSet arbinDataSet;
        private System.Windows.Forms.BindingSource candidateInfoBindingSource;
        private arbinDataSetTableAdapters.CandidateInfoTableAdapter candidateInfoTableAdapter;
        private arbinDataSet1 arbinDataSet1;
        private System.Windows.Forms.BindingSource candidateInfoBindingSource1;
        private arbinDataSet1TableAdapters.CandidateInfoTableAdapter candidateInfoTableAdapter1;
    }
}