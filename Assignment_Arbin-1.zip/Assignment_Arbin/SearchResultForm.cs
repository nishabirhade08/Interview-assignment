﻿namespace Assignment_Arbin
{
    internal class SearchResultForm
    {
    }
}